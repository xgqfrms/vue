<template>
	<header>
    	this is page 1 header
	</header>
</template>

<script>
	export default {
		name: 'page-1-header',
	}
</script>
