<template>
	<header>
		this is page 2 footer
	</header>
</template>

<script>
	export default {
		name: 'page-2-footer',
	}
</script>
